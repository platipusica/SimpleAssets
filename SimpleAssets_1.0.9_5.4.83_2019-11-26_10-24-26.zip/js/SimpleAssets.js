(function($, task) {
"use strict";

function Events1() { // SimpleAssets 

	function on_page_loaded(task) {
		
		$("title").text(task.item_caption);
		$("#title").text(task.item_caption);
		 
		if (task.safe_mode) {
			$("#user-info").text(task.user_info.role_name + ' ' + task.user_info.user_name);
			$('#log-out')
			.show() 
			.click(function(e) {
				e.preventDefault();
				task.logout();
			}); 
		}
		task.server('can_change_password', [], function(res) {
			if (res) {
				$("#menu-right #pass").show();
			}
		});
		
		if (task.full_width) {
			$('#container').removeClass('container').addClass('container-fluid');
		}
		$('#container').show();
		
		task.create_menu($("#menu"), $("#content"), {
			splash_screen: '<h1 class="text-center">Assets Application</h1>',
			view_first: true
		});
	
		$("#menu-right #admin a").click(function(e) {
			var admin = [location.protocol, '//', location.host, location.pathname, 'builder.html'].join('');
			e.preventDefault();
			window.open(admin, '_blank');
		});
		$("#menu-right #about a").click(function(e) {
			e.preventDefault();
			task.message(
				task.templates.find('.about'),
				{title: 'Jam.py framework', margin: 0, text_center: true, 
					buttons: {"OK": undefined}, center_buttons: true}
			);
		});
		$("#menu-right #pass a").click(function(e) {
			e.preventDefault();
			task.change_password.open({open_empty: true});
			task.change_password.append_record();
		});
	
		// $(document).ajaxStart(function() { $("html").addClass("wait"); });
		// $(document).ajaxStop(function() { $("html").removeClass("wait"); });
	} 
	
	function on_view_form_created(item) {
		var table_height = item.table_options.height, 
			height,
			detail,
			detail_container;
	
		item.clear_filters();
		if (item.view_form.hasClass('modal')) {
			item.view_options.width = 1060;
			table_height = $(window).height() - 300;
		}
		else {
			if (!table_height) {
				table_height = $(window).height() - $('body').height() - 20;
			}
		}
		if (item.can_create()) {
			item.view_form.find("#new-btn").on('click.task', function(e) { 
				e.preventDefault();
				if (item.master) {
					item.append_record();
				}
				else {
					item.insert_record();				
				}
			});
		}
		else {
			item.view_form.find("#new-btn").prop("disabled", true);
		}
		
		item.view_form.find("#edit-btn").on('click.task', function(e) { 
			e.preventDefault();
			item.edit_record();
		});
		
		if (item.can_delete()) {
			item.view_form.find("#delete-btn").on('click.task', function(e) { 
				e.preventDefault();
				item.delete_record(); 
			});
		}
		else {
			item.view_form.find("#delete-btn").prop("disabled", true);
		}
		
		if (!item.master && item.owner.on_view_form_created) {
			item.owner.on_view_form_created(item);
		}
	
		if (item.on_view_form_created) {
			item.on_view_form_created(item);
		}
		
		if (item.view_form.find(".view-table").length) {
			if (item.view_options.view_detail) {
				detail_container = item.view_form.find('.view-detail');
				if (detail_container) {
					height = item.view_options.detail_height;
					if (!height) {
						height = 200;
					}
					item.create_detail_table(detail_container, {height: height});
					table_height -= height;
				}
			}
			if (item.master) {
				table_height = item.master.edit_options.detail_height;
				if (!table_height) {
					table_height = 260;
				}
			}
			if (!item.table_options.height) {
				item.table_options.height = table_height;
			}
			item.create_table(item.view_form.find(".view-table"));
			if (!item.master && !item.virtual_table) {
				item.open(true);
			}
		}
		create_print_btns(item);
		return true;
	}
	
	function on_view_form_shown(item) {
		item.view_form.find('.dbtable.' + item.item_name + ' .inner-table').focus();
	}
	
	function on_view_form_closed(item) {
		if (!item.master && !item.virtual_table) {
			item.close();
		}
	}
	
	function on_edit_form_created(item) {
		item.edit_form.find("#cancel-btn").on('click.task', function(e) { item.cancel_edit(e) });
		item.edit_form.find("#ok-btn").on('click.task', function() { item.apply_record() });
		
		if (!item.master && item.owner.on_edit_form_created) {
			item.owner.on_edit_form_created(item);
		}
	
		if (item.on_edit_form_created) {
			item.on_edit_form_created(item);
		}
			
		item.create_inputs(item.edit_form.find(".edit-body"));
		item.create_detail_views(item.edit_form.find(".edit-detail"));
	
		return true;
	}
	
	function on_edit_form_close_query(item) {
		var result = true;
		if (item.is_changing()) {
			if (item.is_modified()) {
				item.yes_no_cancel(task.language.save_changes,
					function() {
						item.apply_record();
					},
					function() {
						item.cancel_edit();
					}
				);
				result = false;
			}
			else {
				item.cancel_edit();
			}
		}
		return result;
	}
	
	function on_filter_form_created(item) {
		item.filter_options.title = item.item_caption + ' - filters';
		// item.filter_options.close_focusout = true;
		item.create_filter_inputs(item.filter_form.find(".edit-body"));
		item.filter_form.find("#cancel-btn").on('click.task', function() {
			item.close_filter_form(); 
		});
		item.filter_form.find("#ok-btn").on('click.task', function() { 
			item.set_order_by(item.view_options.default_order);
			item.apply_filters(item._search_params); 
		});
	}
	
	function on_param_form_created(item) {
		item.create_param_inputs(item.param_form.find(".edit-body"));
		item.param_form.find("#cancel-btn").on('click.task', function() { 
			item.close_param_form();
		});
		item.param_form.find("#ok-btn").on('click.task', function() { 
			item.process_report();
		});
	}
	
	function on_before_print_report(report) {
		var select;
		report.extension = 'pdf';
		if (report.param_form) {
			select = report.param_form.find('select');
			if (select && select.val()) {
				report.extension = select.val();
			}
		}
	}
	
	function on_view_form_keyup(item, event) {
		if (event.keyCode === 45 && event.ctrlKey === true){
			if (item.master) {
				item.append_record();
			}
			else {
				item.insert_record();				
			}
		}
		else if (event.keyCode === 46 && event.ctrlKey === true){
			item.delete_record(); 
		}
	}
	
	function on_edit_form_keyup(item, event) {
		if (event.keyCode === 13 && event.ctrlKey === true){
			item.edit_form.find("#ok-btn").focus(); 
			item.apply_record();
		}
	}
	
	function create_print_btns(item) {
		var i,
			$ul,
			$li,
			reports = [];
		if (item.reports) {
			for (i = 0; i < item.reports.length; i++) {
				if (item.reports[i].can_view()) {
					reports.push(item.reports[i]);
				}
			}
			if (reports.length) {
				$ul = item.view_form.find("#report-btn ul");
				for (i = 0; i < reports.length; i++) {
					$li = $('<li><a href="#">' + reports[i].item_caption + '</a></li>');
					$li.find('a').data('report', reports[i]);
					$li.on('click', 'a', function(e) {
						e.preventDefault();
						$(this).data('report').print(false);
					});
					$ul.append($li);
				}
			}
			else {
				item.view_form.find("#report-btn").hide();
			}
		}
		else {
			item.view_form.find("#report-btn").hide();
		}
	}
	this.on_page_loaded = on_page_loaded;
	this.on_view_form_created = on_view_form_created;
	this.on_view_form_shown = on_view_form_shown;
	this.on_view_form_closed = on_view_form_closed;
	this.on_edit_form_created = on_edit_form_created;
	this.on_edit_form_close_query = on_edit_form_close_query;
	this.on_filter_form_created = on_filter_form_created;
	this.on_param_form_created = on_param_form_created;
	this.on_before_print_report = on_before_print_report;
	this.on_view_form_keyup = on_view_form_keyup;
	this.on_edit_form_keyup = on_edit_form_keyup;
	this.create_print_btns = create_print_btns;
}

task.events.events1 = new Events1();

function Events13() { // SimpleAssets.catalogs.parts 

	function on_view_form_created(item) {
		if (!item.lookup_field) {
			item.table_options.height = $(window).height() - $('body').height() - 220;
			item.asset_parts = task.asset_parts.copy();
			item.asset_parts.paginate = false;
			item.asset_parts.create_table(item.view_form.find('.view-detail'), {
				height: 200,
				summary_fields: ['total','quantity'],
				on_dblclick: function() {
					show_assets(item.asset_parts);
				}
			});
			item.alert('Double-click the record in the bottom table to see the Assets with Part.');
		}
	}
	
	var scroll_timeout;
	
	function on_after_scroll(item) {
		if (!item.lookup_field && item.view_form.length) {
			clearTimeout(scroll_timeout);
			scroll_timeout = setTimeout(
				function() {
					if (item.rec_count) {
						item.asset_parts.set_where({part: item.id.value});
						// item.asset_parts.set_order_by(['-date']);
						item.asset_parts.open(true);
					}
					else {
						item.asset_parts.close();
					}
				},
				100
			);
		}
	}
	
	function show_assets(asset_parts) {
		var assets = task.asset_journal.copy();
		assets.set_where({id: asset_parts.master_rec_id.value});
		assets.open(function(i) {
			i.edit_options.modeless = false;
			i.can_modify = false;
			i.asset_parts.on_after_open = function(t) {
				t.locate('id', asset_parts.id.value);
			};
			i.edit_record();
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_scroll = on_after_scroll;
	this.show_assets = show_assets;
}

task.events.events13 = new Events13();

function Events15() { // SimpleAssets.catalogs.employees 

	function on_view_form_created(item) {
		if (!item.lookup_field) {
			item.table_options.height = $(window).height() - $('body').height() - 220;
			item.assets_assignments = task.assets_assignments.copy();
			item.assets_assignments.paginate = false;
			item.assets_assignments.create_table(item.view_form.find('.view-detail'), {
				height: 200,
				summary_fields: ['employee', ],
				on_dblclick: function() {
					show_assets(item.assets_assignments);
				}
			});
			item.alert('Double-click the record in the bottom table to see the Employee with Assets.');
		}
	}
	
	var scroll_timeout;
	
	function on_after_scroll(item) {
		if (!item.lookup_field && item.view_form.length) {
			clearTimeout(scroll_timeout);
			scroll_timeout = setTimeout(
				function() {
					if (item.rec_count) {
						item.assets_assignments.set_where({employee: item.id.value});
						item.assets_assignments.set_order_by(['-end_date']);
						item.assets_assignments.open(true);
					}
					else {
						item.assets_assignments.close();
					}
				},
				100
			);
		}
	}
	
	function show_assets(assets_assignments) {
		var assets = task.asset_journal.copy();
		assets.set_where({id: assets_assignments.master_rec_id.value});
		assets.open(function(i) {
			i.edit_options.modeless = false;
			i.can_modify = false;
			i.assets_assignments.on_after_open = function(t) {
				t.locate('id', assets_assignments.id.value);
			};
			i.edit_record();
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_scroll = on_after_scroll;
	this.show_assets = show_assets;
}

task.events.events15 = new Events15();

function Events20() { // SimpleAssets.journals.asset_journal 

	function on_field_get_text(field) {
		if (field.field_name === 'assets' && field.value) {
			return field.owner.asset_tag.lookup_text + ' ' + field.lookup_text;
		}
	}
	
	function on_field_get_html(field) {
		if (field.field_name === 'total') {
			if (field.value > 10) {
				return '<strong>' + field.display_text + '</strong>';
			}
		}
	}
	
	function on_field_changed(field, lookup_item) {
		var item = field.owner;
		if (field.field_name === 'gstrate') {
			item.asset_parts.each(function(t) {
				t.edit();
				t.calc(t);
				t.post();
			});
			item.asset_parts.first();
		}
	}
	
	function on_detail_changed(item, detail) {
		var fields = [
			{"total": "total"}, 
			{"gst": "gst"}, 
			{"subtotal": "amount"}
		];  
		item.calc_summary(detail, fields);
	}
	this.on_field_get_text = on_field_get_text;
	this.on_field_get_html = on_field_get_html;
	this.on_field_changed = on_field_changed;
	this.on_detail_changed = on_detail_changed;
}

task.events.events20 = new Events20();

function Events23() { // SimpleAssets.analytics.dashboard 

	function on_view_form_created(item) {
		show_assets(item, item.view$('#assets-canvas')[0].getContext('2d')),
		show_parts(item, item.view$('#parts-canvas')[0].getContext('2d'));
		show_parts_table(item,item.view$('#parts_table-canvas')[0].getContext('2d'));
		show_parts_suppliers(item,item.view$('#parts_suppliers-canvas')[0].getContext('2d'));	
	}
	
	function show_assets(item, ctx) {
		var assets = item.task.asset_journal.copy({handlers: false});
		assets.open(
			{
				fields: ['asset', 'total'],
				funcs: {total: 'sum'},
				group_by: ['asset'],
				order_by: ['-total'],
				limit: 5
			},
			function() {
				var labels = [],
					data = [],
					colors = [];
				assets.each(function(i) {
					labels.push(i.asset.display_text);
					data.push(i.total.value.toFixed(2));
					colors.push(lighten('#006bb3', (i.rec_no - 1) / 5));
				});
				assets.first();
				draw_chart(item, ctx, labels, data, colors, 'Five most valuable assets with parts');
				assets.create_table(item.view$('#assets-table'),
					{row_count: 10, dblclick_edit: true, row_line_count: 1, 
					expand_selected_row: 0, summary_fields: []});
			}
		);
		return assets;
	}
	
	function show_parts(item, ctx) {
		var parts = item.task.parts.copy({handlers: false});
		parts.open(
			{
				fields: ['part_tag', 'quantity'],
				order_by: ['-quantity'],
				limit: 10
			},
	
			function() {
				var labels = [],
					data = [],
					colors = [];
				parts.each(function(t) {
					labels.push(t.part_tag.display_text);
					data.push(t.quantity.value);
					colors.push(lighten('#00b3a2', (t.rec_no - 1) / 10));
				});
				parts.first();
				parts.part_tag.field_caption = 'Part Tag';
				draw_chart(item, ctx, labels, data, colors, 'Ten most popular parts ordered');
				parts.create_table(item.view$('#parts-table'),
					{row_count: 10, dblclick_edit: true, row_count: 10, row_line_count: 1, 
					expand_selected_row: 0, summary_fields: []});
			}
		);
		return parts;
	}
	
	function show_parts_table(item, ctx) {
		var parts_table = item.task.asset_parts.copy({handlers: false});
		parts_table.open(
			{
				fields: ['part', 'quantity'],
				funcs: {quantity: 'sum'},	   
				group_by: ['part'],
				order_by: ['-quantity'],
				limit: 10
			},
	
			function() {
				var labels = [],
					data = [],
					colors = [];
				parts_table.each(function(t) {
					labels.push(t.part.display_text);
					data.push(t.quantity.value);
					colors.push(lighten('#0099ff', (t.rec_no - 1) / 10));
				});
				parts_table.first();
				parts_table.part.field_caption = 'Part Tag';
				draw_chart(item, ctx, labels, data, colors, 'Ten most popular parts assigned');
				parts_table.create_table(item.view$('#parts_table-table'),
					{row_count: 10, dblclick_edit: true});
			}
		);
		return parts_table;
	}
	function show_parts_suppliers(item, ctx) {
		var parts_suppliers = item.task.parts.copy({handlers: false});
		parts_suppliers.open(
			{
				fields: ['supplier', 'quantity'],
				funcs: {quantity: 'sum'},	   
				group_by: ['supplier'],
				order_by: ['-quantity'],
				limit: 10
			},
	
			function() {
				var labels = [],
					data = [],
					colors = [];
				parts_suppliers.each(function(t) {
					labels.push(t.supplier.display_text);
					data.push(t.quantity.value);
					colors.push(lighten('#196619', (t.rec_no - 1) / 10));
				});
				parts_suppliers.first();
				parts_suppliers.supplier.field_caption = 'Supplier';
				draw_chart(item, ctx, labels, data, colors, 'Ten most popular suppliers');
				parts_suppliers.create_table(item.view$('#parts_suppliers-table'),
					{row_count: 10, dblclick_edit: true});
			}
		);
		return parts_suppliers;
	}
	
	
	function draw_chart(item, ctx, labels, data, colors, title) {
		new Chart(ctx,{
			type: 'pie',
			data: {
				labels: labels,
				datasets: [
					{
						data: data,
						backgroundColor: colors
					}
				]
			},
			options: {
				 title: {
					display: true,
					fontsize: 14,
					text: title
				},
				legend: {
					position: 'bottom',
				},
			}
		});
	}
	
	function lighten(color, luminosity) {
		color = color.replace(/[^0-9a-f]/gi, '');
		if (color.length < 6) {
			color = color[0]+ color[0]+ color[1]+ color[1]+ color[2]+ color[2];
		}
		luminosity = luminosity || 0;
		var newColor = "#", c, i, black = 0, white = 255;
		for (i = 0; i < 3; i++) {
			c = parseInt(color.substr(i*2,2), 16);
			c = Math.round(Math.min(Math.max(black, c + (luminosity * white)), white)).toString(16);
			newColor += ("00"+c).substr(c.length);
		}
		return newColor;
	}
	this.on_view_form_created = on_view_form_created;
	this.show_assets = show_assets;
	this.show_parts = show_parts;
	this.show_parts_table = show_parts_table;
	this.show_parts_suppliers = show_parts_suppliers;
	this.draw_chart = draw_chart;
	this.lighten = lighten;
}

task.events.events23 = new Events23();

function Events25() { // SimpleAssets.journals.asset_journal.asset_parts 

	function calc(item) {
		item.amount.value = item.round(item.quantity.value * item.unit_price.value, 2);
		item.gst.value = item.round(item.amount.value * item.owner.gstrate.value / 100, 2);
		item.total.value = item.amount.value + item.gst.value;
	}
	
	function on_field_changed(field, lookup_item) {
		var item = field.owner;
		if (field.field_name === 'part' && lookup_item) {
			item.unit_price.value = lookup_item.price.value;
		}
		else if (field.field_name === 'quantity' || field.field_name === 'unit_price') {
			calc(item);
		}
	}
	
	function on_view_form_created(item) {
		var btn = item.add_view_button('Select', {type: 'primary', btn_id: 'select-btn'});
		btn.click(function() {
			item.select_records('part');
		});
	}
	
	function on_after_append(item) {
		item.quantity.value = 1;
		// item.part_added.value = new Date();
	}
	this.calc = calc;
	this.on_field_changed = on_field_changed;
	this.on_view_form_created = on_view_form_created;
	this.on_after_append = on_after_append;
}

task.events.events25 = new Events25();

function Events28() { // SimpleAssets.catalogs.change_password 

	function on_edit_form_created(item) {
		item.edit_form.find("#ok-btn")
			.off('click.task')
			.on('click', function() { change_password(item) });
	}
	
	function change_password(item) {
		item.post();
		item.server('change_password', [item.old_password.value, item.new_password.value], function(res) {
			if (res) {
				item.warning('Password has been changed. <br> The application will be reloaded.', function() {
					task.logout();
					location.reload(); 
				});
			}
			else {
				item.alert_error("Can't change the password.");	
				item.edit();
			}
		});
	}
	
	function on_field_changed(field, lookup_item) {
		var item = field.owner;
		if (field.field_name === 'old_password') {
			item.server('check_old_password', [field.value], function(error) {
				if (error) {
					item.alert_error(error);	
				}
			});
		}
	}
	this.on_edit_form_created = on_edit_form_created;
	this.change_password = change_password;
	this.on_field_changed = on_field_changed;
}

task.events.events28 = new Events28();

})(jQuery, task)